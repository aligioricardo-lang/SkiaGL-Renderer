#!/system/bin/sh
logcat -G 128K &>/dev/null

# Function to print with a clearer format
print_line() {
    ui_print "***************************************"
}

# trimming
trim_partition () {
    for partition in system vendor data cache metadata odm system_ext product;do sm fstrim "/$partition";done>/dev/null 2>&1 &
    sleep 3
}

# delete trash & log by @Algy_Dev
delete_trash_logs () {
# Clear trash on /data/data
for DIR in /data/data/*; do
  if [ -d "${DIR}" ]; then
    rm -rf ${DIR}/cache/*
    rm -rf ${DIR}/no_backup/*
    rm -rf ${DIR}/app_webview/*
    rm -rf ${DIR}/code_cache/*
  fi
done

# Cache cleaner by Taka
    # Search and clear the apps cache in the "/data/data" directory
    find /data/data/*/cache/* -delete &>/dev/null
    # Search and clear the apps code_cache in the "/data/data" directory
    find /data/data/*/code_cache/* -delete &>/dev/null
    # Search and clear the apps cache in the "/data/user_de/{UID}" directory
    find /data/user_de/*/*/cache/* -delete &>/dev/null
    # Search and clear the apps code_cache in the "/data/user_de/{UID}" directory
    find /data/user_de/*/*/code_cache/* -delete &>/dev/null
    # Search and clear the apps cache in the "/sdcard/Android/data" directory
    find /sdcard/Android/data/*/cache/* -delete &>/dev/null
}

ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICES=$(getprop ro.product.board)
MANUFACTURER=$(getprop ro.product.manufacturer)
API=$(getprop ro.build.version.sdk)
NAME="SkiaGL Renderer | Algy"
VERSION="1.0 | Personal"
DATE=$(date)

printf "░█▀▀▀█ ░█─▄▀ ▀█▀ ─█▀▀█ ░█▀▀█ ░█─── ── ░█▀▀█ 
─▀▀▀▄▄ ░█▀▄─ ░█─ ░█▄▄█ ░█─▄▄ ░█─── ▀▀ ░█▄▄▀ 
░█▄▄▄█ ░█─░█ ▄█▄ ░█─░█ ░█▄▄█ ░█▄▄█ ── ░█─░█"
ui_print ""
sleep 0.5
printf " adjusts rendering for smoother performance."
sleep 0.2
ui_print ""
print_line
printf "- Name            : ${NAME}"
sleep 0.2
printf "- Version         : ${VERSION}"
sleep 0.2
printf "- Android Version : ${ANDROIDVERSION:-Unknown}"
sleep 0.2
printf "- Current Date    : ${DATE}"
sleep 0.2
print_line
printf "- Devices         : ${DEVICES:-Unknown}"
sleep 0.2
printf "- Manufacturer    : ${MANUFACTURER:-Unknown}"
sleep 0.2
print_line
printf "- Trimming up Partitions"
trim_partition &>/dev/null
printf "- Deleting Cache and Trash"
delete_trash_logs &>/dev/null
sleep 2

# Set permissions
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system/bin 0 0 0755 0755

# closing or peak completion of the flash module
logcat -c &>/dev/null