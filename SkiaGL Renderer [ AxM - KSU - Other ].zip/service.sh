#!/system/bin/sh
#
# Celestial-ProcShift by the Algy  
# Open-source powered — with appreciation to GL-DP and all contributors.  
# Licensed under the MIT License.  
#
# Automatically adjusts process priorities (nice, renice, and chrt)  
# for optimal scheduling, smoother performance, and balanced system load  
# without adding overhead to background processes.
#

# ----------------- HELPER FUNCTIONS -----------------
send_notification() {
    # Notify user of optimization completion
    cmd notification post -S bigtext -t 'SkiaGL-Renderer 💀' 'tag' 'Status :  Optimization Completed!' >/dev/null 2>&1
}

# ----------------- OPTIMIZATION SECTIONS -----------------
  setprop debug.hwui.renderer skiagl
  setprop debug.renderengine.vulkan false
  setprop debug.renderengine.backend skiaglthreaded
  setprop debug.renderengine.capture_skia_ms 0
  setprop debug.renderengine.skia_atrace_enabled false
  setprop debug.hwui.skia_use_perfetto_track_events false
  setprop debug.hwui.skia_tracing_enabled false
  setprop debug.tracing.ctl.hwui.skia_tracing_enabled false
  setprop debug.tracing.ctl.hwui.skia_use_perfetto_track_events false
  setprop debug.tracing.ctl.renderengine.skia_tracing_enabled false
  setprop debug.tracing.ctl.renderengine.skia_use_perfetto_track_events false  
  setprop debug.renderengine.skia_tracing_enabled false
  setprop debug.renderengine.skia_use_perfetto_track_events false
  
  # From @HoyoSlave
  input keyevent 26;eval "$(cmd package list packages|grep -v ia.mo|sed "s/package:/cmd activity force-stop /g"|sed "s/$/\&/g")";input keyevent 26

# Main Execution & Exit script successfully
 sync;send_notification